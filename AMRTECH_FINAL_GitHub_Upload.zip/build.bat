@echo off
echo Building AMRTECH with Images & Links...
pip install -r requirements.txt
pyinstaller --noconfirm --onefile --windowed --name "IPTVSmartersPro_AMRTECH" --icon=AMRTECH_icon.ico --hidden-import=customtkinter --hidden-import=vlc --collect-all customtkinter IPTVSmartersPro_AMRTECH.py
echo Done! Check dist\IPTVSmartersPro_AMRTECH.exe
pause
