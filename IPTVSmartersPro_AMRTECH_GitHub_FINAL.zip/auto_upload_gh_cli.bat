@echo off
echo Using GitHub CLI (gh)...
set /p REPO_NAME="اسم الـ Repo: "
gh repo create %REPO_NAME% --public --source=. --remote=origin --push
echo ✅ Repo created and pushed!
echo Actions building EXE...
pause
