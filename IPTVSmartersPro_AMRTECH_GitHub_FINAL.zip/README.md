# IPTV Smarters Pro - AMRTECH v2.0

![AMRTECH](AMRTECH_icon_512.png)

**BY AMRTECH** - Professional IPTV Player

⚠️ **متطلب أساسي:** يجب تثبيت **VLC 64-bit** من https://www.videolan.org/vlc/

### 🌐 روابطي الرسمية
- 🌐 Website: https://profilable.com/AMRTECH-VIP
- 🛒 Shop: https://shoppy.gg/product/Z3PuojD
- 🔗 Spoo.me: https://spoo.me/Amrtech
- 📢 Telegram Backup: https://t.me/+oGZKLybZyqkxM2Vk

### ✨ المميزات
- 4 ثيمات احترافية
- مشغل VLC مدمج
- دعم M3U / Xtream
- مفضلة + بحث ذكي
- شاشة About باسم AMRTECH
- Cinema Mode

### 🔨 بناء EXE محلياً
```bash
pip install -r requirements.txt
build_AMRTECH_FINAL.bat
```

### 🤖 بناء تلقائي عبر GitHub Actions
كل Push سيبني EXE تلقائياً ويظهر في تبويب Actions > Artifacts

### 📦 التثبيت
- المثبت يفحص وجود VLC 64-bit
- ينشئ اختصارات مع روابطك
- يدعم العربية والإنجليزية

© 2025 AMRTECH
