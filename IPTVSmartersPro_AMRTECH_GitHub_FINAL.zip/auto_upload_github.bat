@echo off
echo ============================================
echo  IPTV Smarters Pro - AMRTECH
echo  Auto GitHub Uploader
echo ============================================
echo.

set /p REPO_NAME="ادخل اسم الـ Repo (مثال: IPTV-AMRTECH): "
set /p GITHUB_USERNAME="ادخل اسم مستخدم GitHub: "

echo.
echo [1/4] تهيئة Git...
git init
git add .
git branch -M main

echo [2/4] انشاء ملف README...
echo # %REPO_NAME% > README_GH.md

echo [3/4] ربط GitHub...
echo.
echo افتح المتصفح واذهب الى: https://github.com/new
echo انشئ Repo بنفس الاسم: %REPO_NAME%
echo لا تضع README (فارغ)
echo ثم انسخ رابط الـ Repo
echo.
set /p REPO_URL="الصق رابط الـ Repo هنا (https://github.com/USERNAME/REPO.git): "

git remote add origin %REPO_URL%

echo [4/4] رفع الملفات...
git add .
git commit -m "AMRTECH v2.0 - Initial Release with Official Icon & Links - VLC 64-bit Required"
git push -u origin main

echo.
echo ✅ تم الرفع بنجاح!
echo اذهب الى: https://github.com/%GITHUB_USERNAME%/%REPO_NAME%/actions
echo انتظر 3-4 دقائق وسيتم بناء EXE تلقائياً
echo.
pause
