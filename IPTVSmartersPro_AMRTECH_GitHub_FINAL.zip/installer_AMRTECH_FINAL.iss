; IPTV Smarters Pro - AMRTECH FINAL - Official Icon
#define MyAppName "IPTV Smarters Pro - AMRTECH"
#define MyAppVersion "2.0"
#define MyAppPublisher "AMRTECH"
#define MyAppURL "https://profilable.com/AMRTECH-VIP"
#define MyAppExeName "IPTVSmartersPro_AMRTECH.exe"

[Setup]
AppId={{IPTVSmartersPro-AMRTECH-OFFICIAL-ICON-2025}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppCopyright=Copyright (C) 2025 AMRTECH
VersionInfoCompany=AMRTECH
VersionInfoDescription=IPTV Player by AMRTECH - Official
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputBaseFilename=IPTVSmartersPro_AMRTECH_v2.0_Official_Setup
Compression=lzma
WizardStyle=modern
SetupIconFile=AMRTECH_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "AMRTECH_icon.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "AMRTECH_icon_512.png"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\AMRTECH_icon.ico"
Name: "{group}\🌐 Website - Profilable"; Filename: "https://profilable.com/AMRTECH-VIP"
Name: "{group}\🛒 Shoppy Store"; Filename: "https://shoppy.gg/product/Z3PuojD"
Name: "{group}\🔗 Spoo.me"; Filename: "https://spoo.me/Amrtech"
Name: "{group}\📢 Telegram Backup"; Filename: "https://t.me/+oGZKLybZyqkxM2Vk"
Name: "{group}\⬇️ VLC 64-bit"; Filename: "https://www.videolan.org/vlc/"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; IconFilename: "{app}\AMRTECH_icon.ico"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "تشغيل البرنامج"; Flags: nowait postinstall skipifsilent
