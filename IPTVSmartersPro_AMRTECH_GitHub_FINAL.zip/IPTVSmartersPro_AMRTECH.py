import customtkinter as ctk
from tkinter import filedialog, messagebox, StringVar, simpledialog
import re
import json
import webbrowser
import threading
import requests
import time
import subprocess
import shutil
import os
import sys
from pathlib import Path
from urllib.parse import urlparse

try:
    import vlc
    VLC_AVAILABLE = True
except ImportError:
    VLC_AVAILABLE = False

# ============================================================
# 🏷️ AMRTECH BRANDING - OFFICIAL
# ============================================================
APP_NAME = "IPTV Smarters Pro - AMRTECH"
APP_VERSION = "2.0"
APP_AUTHOR = "AMRTECH"
APP_WEBSITE_MAIN = "https://profilable.com/AMRTECH-VIP"
APP_WEBSITE_SHOP = "https://shoppy.gg/product/Z3PuojD"
APP_WEBSITE_SPOO = "https://spoo.me/Amrtech"
APP_TELEGRAM_BACKUP = "https://t.me/+oGZKLybZyqkxM2Vk"
APP_VLC_URL = "https://www.videolan.org/vlc/"
VLC_REQUIRED_URL = APP_VLC_URL
APP_DESCRIPTION = "IPTV Player احترافي - BY AMRTECH"


# ============================================================
# 🎨 MULTI-THEME COLOR SYSTEM
# ============================================================
# Each theme has "dark" and "light" variants
# Colors are calm and elegant — easy on the eyes

THEMES = {
    # ============ 1. OCEAN — Soft Blue & Teal ============
    "ocean": {
        "name": "🌊 Ocean",
        "dark": {
            "bg_main":        "#0d1117",
            "bg_card":        "#161b22",
            "bg_panel":       "#1c2128",
            "bg_hover":       "#21262d",
            "bg_input":       "#1c2128",
            "bg_row":         "#161b22",
            "accent_1":       "#58a6ff",   # Soft blue
            "accent_2":       "#56d4dd",   # Calm teal
            "accent_3":       "#a371f7",   # Muted lavender
            "accent_4":       "#ffa657",   # Warm peach
            "accent_5":       "#7ee787",   # Fresh mint
            "accent_6":       "#ff7b72",   # Soft rose
            "text_primary":   "#e6edf3",
            "text_secondary": "#8b949e",
            "text_muted":     "#6e7681",
            "border":         "#30363d",
            "success":        "#3fb950",
            "danger":         "#f85149",
        },
        "light": {
            "bg_main":        "#f6f8fa",
            "bg_card":        "#ffffff",
            "bg_panel":       "#f6f8fa",
            "bg_hover":       "#eaeef2",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#0969da",
            "accent_2":       "#1b7c83",
            "accent_3":       "#8250df",
            "accent_4":       "#bc4c00",
            "accent_5":       "#1a7f37",
            "accent_6":       "#cf222e",
            "text_primary":   "#1f2328",
            "text_secondary": "#57606a",
            "text_muted":     "#6e7781",
            "border":         "#d0d7de",
            "success":        "#1a7f37",
            "danger":         "#cf222e",
        }
    },
    # ============ 2. SAKURA — Soft Pink & Lavender ============
    "sakura": {
        "name": "🌸 Sakura",
        "dark": {
            "bg_main":        "#1a1014",
            "bg_card":        "#231519",
            "bg_panel":       "#2a1a1f",
            "bg_hover":       "#331f26",
            "bg_input":       "#2a1a1f",
            "bg_row":         "#231519",
            "accent_1":       "#f778ba",   # Soft pink
            "accent_2":       "#d2a8ff",   # Lavender
            "accent_3":       "#ff9eb5",   # Rose pink
            "accent_4":       "#ffb77d",   # Peach
            "accent_5":       "#a5d6ff",   # Sky blue
            "accent_6":       "#ff7b72",   # Coral
            "text_primary":   "#f5e6eb",
            "text_secondary": "#b8a0a8",
            "text_muted":     "#8a7078",
            "border":         "#3d2830",
            "success":        "#7ee787",
            "danger":         "#ff7b72",
        },
        "light": {
            "bg_main":        "#fff5f8",
            "bg_card":        "#ffffff",
            "bg_panel":       "#fff5f8",
            "bg_hover":       "#ffe4ec",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#bf3989",
            "accent_2":       "#8250df",
            "accent_3":       "#cf222e",
            "accent_4":       "#bc4c00",
            "accent_5":       "#0969da",
            "accent_6":       "#cf222e",
            "text_primary":   "#2d1a22",
            "text_secondary": "#6e4a55",
            "text_muted":     "#96707a",
            "border":         "#f0d4dc",
            "success":        "#1a7f37",
            "danger":         "#cf222e",
        }
    },
    # ============ 3. FOREST — Calm Green & Mint ============
    "forest": {
        "name": "🌿 Forest",
        "dark": {
            "bg_main":        "#0e1512",
            "bg_card":        "#141d18",
            "bg_panel":       "#1a241e",
            "bg_hover":       "#202c25",
            "bg_input":       "#1a241e",
            "bg_row":         "#141d18",
            "accent_1":       "#7ee787",   # Mint
            "accent_2":       "#56d4dd",   # Teal
            "accent_3":       "#a8d982",   # Light green
            "accent_4":       "#ffd33d",   # Soft yellow
            "accent_5":       "#79c0ff",   # Sky
            "accent_6":       "#ffa198",   # Coral
            "text_primary":   "#e6f0ea",
            "text_secondary": "#94a89b",
            "text_muted":     "#6d8172",
            "border":         "#2d3d33",
            "success":        "#7ee787",
            "danger":         "#f85149",
        },
        "light": {
            "bg_main":        "#f3f8f4",
            "bg_card":        "#ffffff",
            "bg_panel":       "#f3f8f4",
            "bg_hover":       "#e0ebe2",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#1a7f37",
            "accent_2":       "#1b7c83",
            "accent_3":       "#3fb950",
            "accent_4":       "#9a6700",
            "accent_5":       "#0969da",
            "accent_6":       "#cf222e",
            "text_primary":   "#1a2420",
            "text_secondary": "#4a5a50",
            "text_muted":     "#6e7e74",
            "border":         "#ccd9d0",
            "success":        "#1a7f37",
            "danger":         "#cf222e",
        }
    },
    # ============ 4. SUNSET — Warm Orange & Rose ============
    "sunset": {
        "name": "🌅 Sunset",
        "dark": {
            "bg_main":        "#191210",
            "bg_card":        "#221815",
            "bg_panel":       "#291d1a",
            "bg_hover":       "#33241f",
            "bg_input":       "#291d1a",
            "bg_row":         "#221815",
            "accent_1":       "#ffa657",   # Warm orange
            "accent_2":       "#ff7b72",   # Soft rose
            "accent_3":       "#ffb77d",   # Peach
            "accent_4":       "#ffd33d",   # Yellow
            "accent_5":       "#d2a8ff",   # Lavender
            "accent_6":       "#79c0ff",   # Sky
            "text_primary":   "#f5e6df",
            "text_secondary": "#b8a097",
            "text_muted":     "#8a7568",
            "border":         "#3d2e26",
            "success":        "#7ee787",
            "danger":         "#f85149",
        },
        "light": {
            "bg_main":        "#fff8f2",
            "bg_card":        "#ffffff",
            "bg_panel":       "#fff8f2",
            "bg_hover":       "#ffe8d4",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#bc4c00",
            "accent_2":       "#cf222e",
            "accent_3":       "#953800",
            "accent_4":       "#9a6700",
            "accent_5":       "#8250df",
            "accent_6":       "#0969da",
            "text_primary":   "#2d1a10",
            "text_secondary": "#6e4a35",
            "text_muted":     "#96705a",
            "border":         "#f0d8c0",
            "success":        "#1a7f37",
            "danger":         "#cf222e",
        }
    },
    # ============ 5. ROYAL — Deep Purple & Indigo ============
    "royal": {
        "name": "💜 Royal",
        "dark": {
            "bg_main":        "#0f0d1a",
            "bg_card":        "#171425",
            "bg_panel":       "#1e1a2e",
            "bg_hover":       "#252038",
            "bg_input":       "#1e1a2e",
            "bg_row":         "#171425",
            "accent_1":       "#a371f7",   # Purple
            "accent_2":       "#79c0ff",   # Sky
            "accent_3":       "#d2a8ff",   # Lavender
            "accent_4":       "#f778ba",   # Pink
            "accent_5":       "#7ee787",   # Mint
            "accent_6":       "#ffa657",   # Peach
            "text_primary":   "#e6e0f5",
            "text_secondary": "#a89cc0",
            "text_muted":     "#786b90",
            "border":         "#322a48",
            "success":        "#7ee787",
            "danger":         "#f85149",
        },
        "light": {
            "bg_main":        "#f8f5ff",
            "bg_card":        "#ffffff",
            "bg_panel":       "#f8f5ff",
            "bg_hover":       "#ebe2ff",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#8250df",
            "accent_2":       "#0969da",
            "accent_3":       "#a371f7",
            "accent_4":       "#bf3989",
            "accent_5":       "#1a7f37",
            "accent_6":       "#bc4c00",
            "text_primary":   "#1e1830",
            "text_secondary": "#4a3f70",
            "text_muted":     "#726a90",
            "border":         "#d8cef0",
            "success":        "#1a7f37",
            "danger":         "#cf222e",
        }
    },
    # ============ 6. MONO — Pure Grayscale ============
    "mono": {
        "name": "⬛ Mono",
        "dark": {
            "bg_main":        "#0d0d0d",
            "bg_card":        "#161616",
            "bg_panel":       "#1c1c1c",
            "bg_hover":       "#242424",
            "bg_input":       "#1c1c1c",
            "bg_row":         "#161616",
            "accent_1":       "#e6e6e6",
            "accent_2":       "#b0b0b0",
            "accent_3":       "#8a8a8a",
            "accent_4":       "#cfcfcf",
            "accent_5":       "#ffffff",
            "accent_6":       "#f0f0f0",
            "text_primary":   "#f5f5f5",
            "text_secondary": "#a8a8a8",
            "text_muted":     "#707070",
            "border":         "#2e2e2e",
            "success":        "#e6e6e6",
            "danger":         "#cfcfcf",
        },
        "light": {
            "bg_main":        "#f5f5f5",
            "bg_card":        "#ffffff",
            "bg_panel":       "#f5f5f5",
            "bg_hover":       "#e5e5e5",
            "bg_input":       "#ffffff",
            "bg_row":         "#ffffff",
            "accent_1":       "#1f1f1f",
            "accent_2":       "#4a4a4a",
            "accent_3":       "#6e6e6e",
            "accent_4":       "#3a3a3a",
            "accent_5":       "#000000",
            "accent_6":       "#2a2a2a",
            "text_primary":   "#1a1a1a",
            "text_secondary": "#4a4a4a",
            "text_muted":     "#7a7a7a",
            "border":         "#d4d4d4",
            "success":        "#1a1a1a",
            "danger":         "#3a3a3a",
        }
    },
}

THEME_ORDER = ["ocean", "sakura", "forest", "sunset", "royal", "mono"]

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

CONFIG_FILE = Path.home() / ".iptv_smarters_config.json"


class IPTVSmartersPro(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title(f"{APP_NAME} v{APP_VERSION} - {APP_AUTHOR}")
        self.geometry("1360x820")
        self.minsize(1180, 740)

        self.channels = []
        self.live_channels = []
        self.movie_channels = []
        self.series_channels = []
        self.live_categories = []
        self.movie_categories = []
        self.series_categories = []
        self.favorites = []
        self.current_playlist = None
        self.selected_channel = None
        self._last_played = None
        self.is_xtream = False
        self.xtream_info = {}
        self.current_theme = "dark"          # dark / light
        self.current_color_theme = "ocean"   # ocean / sakura / forest / ...
        self.current_category = "live"
        self.current_package = None

        # Player state
        self.volume = 80
        self.is_muted = False
        self.video_scale = 1.0
        self.left_panel_visible = True
        # Cinema mode
        self.cinema_mode = False
        self.ui_visible = True
        self.hide_ui_timer = None
        self.data_used_mb = 0.0
        self.playing_start_time = None
        self.data_timer = None
        self.progress_timer = None
        self.is_seeking = False
        self.is_fullscreen = False

        self.instance = None
        self.player = None
        if VLC_AVAILABLE:
            self.instance = vlc.Instance("--no-xlib")
            self.player = self.instance.media_player_new()
            self.player.audio_set_volume(self.volume)

        self.load_config()
        self.C = self._get_palette()
        self.apply_theme(self.current_theme, self.current_color_theme)

        # ==================== Welcome Screen ====================
        self.welcome_frame = ctk.CTkFrame(self, fg_color=self.C["bg_main"])
        self.welcome_frame.pack(fill="both", expand=True)
        # AMRTECH branding
        try:
            bl = ctk.CTkLabel(self.welcome_frame, text="© 2025 AMRTECH - VLC 64-bit Required | profilable.com/AMRTECH-VIP", font=ctk.CTkFont(size=10), text_color=self.C["text_muted"])
            bl.pack(side="bottom", pady=2)
            ab = ctk.CTkButton(self.welcome_frame, text="👤 About AMRTECH", width=160, height=30, corner_radius=8, fg_color=self.C["accent_3"], hover_color=self.C["accent_1"], font=ctk.CTkFont(size=11, weight="bold"), command=self.show_about)
            ab.pack(side="bottom", pady=5)
        except: pass

        # ==================== HERO BANNER ====================
        self.hero_banner = ctk.CTkFrame(
            self.welcome_frame, height=250, corner_radius=0,
            fg_color=self.C["bg_card"]
        )
        self.hero_banner.pack(fill="x")
        self.hero_banner.pack_propagate(False)

        # Gradient decorative strip
        self.strip_frame = ctk.CTkFrame(self.hero_banner, height=6, fg_color="transparent")
        self.strip_frame.pack(fill="x", side="top")
        for key in ["accent_1", "accent_2", "accent_3", "accent_4", "accent_5", "accent_6"]:
            strip = ctk.CTkFrame(self.strip_frame, height=6, fg_color=self.C[key], corner_radius=0)
            strip.pack(side="left", fill="x", expand=True)

        # Hero content
        hero_content = ctk.CTkFrame(self.hero_banner, fg_color="transparent")
        hero_content.pack(expand=True, pady=22)

        self.hero_icon = ctk.CTkLabel(
            hero_content, text="📺",
            font=ctk.CTkFont(size=68)
        )
        self.hero_icon.pack()

        self.hero_title = ctk.CTkLabel(
            hero_content, text="IPTV Smarters AMRTECH",
            font=ctk.CTkFont(family="Segoe UI", size=38, weight="bold"),
            text_color=self.C["text_primary"]
        )
        self.hero_title.pack(pady=(8, 0))

        self.hero_sub = ctk.CTkLabel(
            hero_content, text="P R O   ·   E D I T I O N   2 0 2 6",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color=self.C["accent_1"]
        )
        self.hero_sub.pack(pady=(2, 6))

        self.hero_tagline = ctk.CTkLabel(
            hero_content, text="Premium Streaming Experience",
            font=ctk.CTkFont(size=13),
            text_color=self.C["text_secondary"]
        )
        self.hero_tagline.pack()

        # ==================== Welcome Card ====================
        self.card_container = ctk.CTkFrame(self.welcome_frame, fg_color="transparent")
        self.card_container.pack(fill="both", expand=True, padx=40, pady=20)

        self.card = ctk.CTkFrame(
            self.card_container, corner_radius=20,
            fg_color=self.C["bg_card"],
            border_width=1, border_color=self.C["border"]
        )
        self.card.pack(fill="both", expand=True, padx=100, pady=10)

        ctk.CTkLabel(
            self.card, text="Get Started",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color=self.C["text_primary"]
        ).pack(pady=(30, 4))

        ctk.CTkLabel(
            self.card, text="Choose how you'd like to load your content",
            font=ctk.CTkFont(size=12),
            text_color=self.C["text_secondary"]
        ).pack(pady=(0, 22))

        # ========== Main Buttons ==========
        btn_container = ctk.CTkFrame(self.card, fg_color="transparent")
        btn_container.pack(pady=4)

        self.btn_load = ctk.CTkButton(
            btn_container, text="📁   Load Playlist",
            width=380, height=58, corner_radius=14,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=self.C["accent_1"], hover_color=self.C["accent_3"],
            text_color="#ffffff",
            anchor="w",
            command=self.load_playlist_menu
        )
        self.btn_load.pack(pady=6)

        self.btn_api = ctk.CTkButton(
            btn_container, text="🔗   Xtream Codes API",
            width=380, height=58, corner_radius=14,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=self.C["accent_2"], hover_color=self.C["accent_5"],
            text_color="#ffffff",
            anchor="w",
            command=self.open_xtream_login
        )
        self.btn_api.pack(pady=6)

        self.btn_local = ctk.CTkButton(
            btn_container, text="🎵   Local Media Files",
            width=380, height=58, corner_radius=14,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=self.C["accent_3"], hover_color=self.C["accent_6"],
            text_color="#ffffff",
            anchor="w",
            command=self.local_media
        )
        self.btn_local.pack(pady=6)

        # ========== Bottom Actions ==========
        bottom_actions = ctk.CTkFrame(self.card, fg_color="transparent")
        bottom_actions.pack(pady=(20, 10))

        # 🎨 Theme Color Cycle button (NEW!)
        self.btn_color_theme = ctk.CTkButton(
            bottom_actions, text=f"🎨   {THEMES[self.current_color_theme]['name']}",
            width=200, height=44, corner_radius=12,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_3"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.cycle_color_theme
        )
        self.btn_color_theme.pack(side="left", padx=5)

        self.btn_favorites_home = ctk.CTkButton(
            bottom_actions, text="★   Favorites",
            width=160, height=44, corner_radius=12,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_4"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.show_favorites
        )
        self.btn_favorites_home.pack(side="left", padx=5)

        # 🌙/☀️ Light-Dark Toggle
        self.btn_theme = ctk.CTkButton(
            bottom_actions, text="🌙   Dark",
            width=160, height=44, corner_radius=12,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.toggle_theme
        )
        self.btn_theme.pack(side="left", padx=5)

        # ========== Footer ==========
        footer = ctk.CTkFrame(self.welcome_frame, fg_color="transparent")
        footer.pack(side="bottom", fill="x", pady=12)

        ctk.CTkLabel(
            footer,
            text="By using this application, you agree to our  ",
            font=ctk.CTkFont(size=11),
            text_color=self.C["text_muted"]
        ).pack(side="left", padx=(40, 0))

        terms_link = ctk.CTkLabel(
            footer, text="Terms of Service",
            font=ctk.CTkFont(size=11, underline=True),
            text_color=self.C["accent_1"], cursor="hand2"
        )
        terms_link.pack(side="left")
        terms_link.bind("<Button-1>", lambda e: webbrowser.open("https://www.example.com/terms"))

        ctk.CTkLabel(
            footer, text="  ·  v2.0.26",
            font=ctk.CTkFont(size=11),
            text_color=self.C["text_muted"]
        ).pack(side="left")

        # ==================== Player Screen ====================
        self.player_frame = ctk.CTkFrame(self, fg_color=self.C["bg_main"])

        # ---------- TOP BAR ----------
        self.top_bar = ctk.CTkFrame(self.player_frame, height=56,
                                    fg_color=self.C["bg_card"], corner_radius=0)
        self.top_bar.pack(fill="x")
        self.top_bar.pack_propagate(False)

        self.btn_back = ctk.CTkButton(
            self.top_bar, text="← Back", width=90, height=36, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.show_welcome
        )
        self.btn_back.pack(side="left", padx=(12, 8), pady=10)

        self.playlist_title = ctk.CTkLabel(
            self.top_bar, text="Channel List",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=self.C["text_primary"]
        )
        self.playlist_title.pack(side="left", padx=8)

        # 🌙 Light-Dark toggle (top bar)
        self.btn_theme_player = ctk.CTkButton(
            self.top_bar, text="🌙", width=40, height=36, corner_radius=10,
            font=ctk.CTkFont(size=15),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.toggle_theme
        )
        self.btn_theme_player.pack(side="right", padx=(6, 12), pady=10)

        # 🎨 Color theme cycle button (top bar)
        self.btn_color_theme_player = ctk.CTkButton(
            self.top_bar, text="🎨", width=40, height=36, corner_radius=10,
            font=ctk.CTkFont(size=15),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_3"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.cycle_color_theme
        )
        self.btn_color_theme_player.pack(side="right", padx=6, pady=10)

        self.btn_fav_view = ctk.CTkButton(
            self.top_bar, text="★  Favorites", width=120, height=36, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["accent_4"], hover_color=self.C["accent_6"],
            text_color="#ffffff",
            command=self.show_favorites
        )
        self.btn_fav_view.pack(side="right", padx=6, pady=10)

        self.search_var = StringVar()
        self.search_var.trace_add("write", self.filter_channels)
        self.search_entry = ctk.CTkEntry(
            self.top_bar, placeholder_text="🔍  Search...",
            width=220, height=36, corner_radius=10,
            font=ctk.CTkFont(size=12),
            fg_color=self.C["bg_input"],
            border_color=self.C["border"],
            text_color=self.C["text_primary"],
            placeholder_text_color=self.C["text_muted"],
            textvariable=self.search_var
        )
        self.search_entry.pack(side="right", padx=8, pady=10)

        # ---------- CATEGORY BAR ----------
        self.cat_bar = ctk.CTkFrame(self.player_frame, height=50,
                                    fg_color=self.C["bg_panel"], corner_radius=0)
        self.cat_bar.pack(fill="x")
        self.cat_bar.pack_propagate(False)

        self.btn_live = ctk.CTkButton(
            self.cat_bar, text="📺  Live TV", width=140, height=34, corner_radius=10,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["accent_1"], hover_color=self.C["accent_3"],
            text_color="#ffffff",
            command=lambda: self.switch_main_category("live")
        )
        self.btn_live.pack(side="left", padx=(12, 4), pady=8)

        self.btn_movies = ctk.CTkButton(
            self.cat_bar, text="🎬  Movies", width=140, height=34, corner_radius=10,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_4"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=lambda: self.switch_main_category("movies")
        )
        self.btn_movies.pack(side="left", padx=4, pady=8)

        self.btn_series = ctk.CTkButton(
            self.cat_bar, text="🍿  Series", width=140, height=34, corner_radius=10,
            font=ctk.CTkFont(size=13, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=lambda: self.switch_main_category("series")
        )
        self.btn_series.pack(side="left", padx=4, pady=8)

        # ---------- CONTENT ----------
        self.content_frame = ctk.CTkFrame(self.player_frame, fg_color="transparent")
        self.content_frame.pack(fill="both", expand=True, padx=12, pady=10)

        # ==================== Left panel ====================
        self.left_panel = ctk.CTkFrame(
            self.content_frame, width=440, corner_radius=14,
            fg_color=self.C["bg_card"],
            border_width=1, border_color=self.C["border"]
        )
        self.left_panel.pack(side="left", fill="y", padx=(0, 10))
        self.left_panel.pack_propagate(False)

        pkg_header = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        pkg_header.pack(fill="x", padx=14, pady=(14, 6))
        self.pkg_header_lbl = ctk.CTkLabel(pkg_header, text="CATEGORIES",
                                            font=ctk.CTkFont(size=11, weight="bold"),
                                            text_color=self.C["accent_1"])
        self.pkg_header_lbl.pack(anchor="w")

        self.packages_frame = ctk.CTkScrollableFrame(
            self.left_panel, height=220, fg_color="transparent",
            scrollbar_button_color=self.C["bg_hover"],
            scrollbar_button_hover_color=self.C["accent_1"]
        )
        self.packages_frame.pack(fill="x", padx=8, pady=(0, 6))

        ch_header = ctk.CTkFrame(self.left_panel, fg_color="transparent")
        ch_header.pack(fill="x", padx=14, pady=(6, 4))
        self.ch_header_lbl = ctk.CTkLabel(ch_header, text="CHANNELS",
                                           font=ctk.CTkFont(size=11, weight="bold"),
                                           text_color=self.C["accent_2"])
        self.ch_header_lbl.pack(anchor="w")

        self.channels_container = ctk.CTkScrollableFrame(
            self.left_panel, fg_color="transparent",
            scrollbar_button_color=self.C["bg_hover"],
            scrollbar_button_hover_color=self.C["accent_1"]
        )
        self.channels_container.pack(fill="both", expand=True, padx=8, pady=(0, 10))

        # ==================== Right panel ====================
        self.right_panel = ctk.CTkFrame(
            self.content_frame, corner_radius=14,
            fg_color=self.C["bg_card"],
            border_width=1, border_color=self.C["border"]
        )
        self.right_panel.pack(side="right", fill="both", expand=True)
        self.right_panel.pack_propagate(False)

        self.video_holder = ctk.CTkFrame(self.right_panel, fg_color="transparent")
        self.video_holder.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.video_frame = ctk.CTkFrame(
            self.video_holder, fg_color="#000000", corner_radius=10
        )
        self.video_frame.place(relx=0.5, rely=0.5, anchor="center",
                               relwidth=1, relheight=1)

        self.video_frame.bind("<Double-Button-1>", lambda e: self.toggle_fullscreen())

        # Progress Bar
        self.progress_frame = ctk.CTkFrame(self.right_panel, height=32, fg_color="transparent")
        self.progress_frame.pack(side="bottom", fill="x", padx=14, pady=(0, 4))
        self.progress_frame.pack_propagate(False)

        self.time_current = ctk.CTkLabel(self.progress_frame, text="00:00", width=52,
                                         font=ctk.CTkFont(size=11, weight="bold"),
                                         text_color=self.C["text_secondary"])
        self.time_current.pack(side="left")

        self.progress_slider = ctk.CTkSlider(
            self.progress_frame, from_=0, to=1000, number_of_steps=1000,
            progress_color=self.C["accent_1"],
            button_color=self.C["accent_2"],
            button_hover_color=self.C["accent_3"],
            fg_color=self.C["bg_hover"],
            command=self.on_progress_change
        )
        self.progress_slider.set(0)
        self.progress_slider.pack(side="left", fill="x", expand=True, padx=8)
        self.progress_slider.bind("<Button-1>", self.on_seek_start)
        self.progress_slider.bind("<ButtonRelease-1>", self.on_seek_end)

        self.time_total = ctk.CTkLabel(self.progress_frame, text="00:00", width=52,
                                       font=ctk.CTkFont(size=11, weight="bold"),
                                       text_color=self.C["text_secondary"])
        self.time_total.pack(side="left")

        # Bottom controls
        self.controls = ctk.CTkFrame(self.right_panel, height=64, fg_color="transparent")
        self.controls.pack(side="bottom", fill="x", padx=12, pady=(0, 10))
        self.controls.pack_propagate(False)

        info_frame = ctk.CTkFrame(self.controls, fg_color="transparent")
        info_frame.pack(side="left", fill="y")

        self.selected_label = ctk.CTkLabel(
            info_frame, text="Ready to play",
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=self.C["text_primary"]
        )
        self.selected_label.pack(anchor="w")

        self.data_label = ctk.CTkLabel(
            info_frame, text="Data: 0.00 MB",
            font=ctk.CTkFont(size=11),
            text_color=self.C["text_muted"]
        )
        self.data_label.pack(anchor="w", pady=(1, 0))

        vol_frame = ctk.CTkFrame(self.controls, fg_color="transparent")
        vol_frame.pack(side="right", padx=(6, 4))

        self.btn_mute = ctk.CTkButton(
            vol_frame, text="🔊", width=38, height=36, corner_radius=10,
            font=ctk.CTkFont(size=14),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.toggle_mute
        )
        self.btn_mute.pack(side="left", padx=2)

        self.volume_slider = ctk.CTkSlider(
            vol_frame, from_=0, to=100, width=110, number_of_steps=100,
            progress_color=self.C["accent_2"],
            button_color=self.C["accent_1"],
            button_hover_color=self.C["accent_3"],
            fg_color=self.C["bg_hover"],
            command=self.on_volume_change
        )
        self.volume_slider.set(self.volume)
        self.volume_slider.pack(side="left", padx=4)

        self.vol_label = ctk.CTkLabel(vol_frame, text="80%", width=42,
                                      font=ctk.CTkFont(size=11, weight="bold"),
                                      text_color=self.C["text_secondary"])
        self.vol_label.pack(side="left")

        self.btn_fullscreen = ctk.CTkButton(
            self.controls, text="⛶  Fullscreen", width=130, height=38, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.toggle_fullscreen
        )
        self.btn_fullscreen.pack(side="right", padx=3)

        self.btn_toggle_sidebar = ctk.CTkButton(
            self.controls, text="☰", width=42, height=38, corner_radius=10,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.toggle_left_panel
        )
        self.btn_toggle_sidebar.pack(side="right", padx=3)

        self.btn_external_vlc = ctk.CTkButton(
            self.controls, text="🎬  VLC", width=100, height=38, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["accent_4"], hover_color=self.C["accent_6"],
            text_color="#ffffff",
            command=self.play_in_external_vlc
        )
        self.btn_external_vlc.pack(side="right", padx=3)

        self.btn_zoom_reset = ctk.CTkButton(
            self.controls, text="↺", width=42, height=38, corner_radius=10,
            font=ctk.CTkFont(size=15, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["accent_3"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.reset_video_size
        )
        self.btn_zoom_reset.pack(side="right", padx=3)

        self.btn_stop = ctk.CTkButton(
            self.controls, text="⏹  Stop", width=100, height=38, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["bg_hover"], hover_color=self.C["danger"],
            text_color=self.C["text_primary"],
            border_width=1, border_color=self.C["border"],
            command=self.stop_playback
        )
        self.btn_stop.pack(side="right", padx=3)

        self.btn_play = ctk.CTkButton(
            self.controls, text="▶  Play", width=110, height=38, corner_radius=10,
            font=ctk.CTkFont(size=12, weight="bold"),
            fg_color=self.C["accent_5"], hover_color=self.C["success"],
            text_color="#000000",
            command=self.play_selected, state="disabled"
        )
        self.btn_play.pack(side="right", padx=3)

        # ==================== Keyboard Shortcuts ====================
        self.bind("<Escape>", lambda e: self.exit_fullscreen())
        self.bind("<Control-plus>",  lambda e: self.enlarge_video())
        self.bind("<Control-equal>", lambda e: self.enlarge_video())
        self.bind("<Control-minus>", lambda e: self.shrink_video())
        self.bind("<Control-Key-0>", lambda e: self.reset_video_size())
        self.bind("<Control-h>",     lambda e: self.toggle_left_panel())
        self.bind("<Key-f>",         lambda e: self.toggle_cinema_mode())
        self.bind("<Key-v>",         lambda e: self.play_in_external_vlc())
        self.bind("<Key-t>",         lambda e: self.toggle_theme())          # NEW: T = light/dark
        self.bind("<Key-c>",         lambda e: self.cycle_color_theme())     # NEW: C = cycle colors

        self.bind_all("<Motion>", self._on_mouse_motion)
        self.bind_all("<Enter>", self._on_mouse_motion)

        self.video_holder.bind("<Configure>", self._on_holder_resize)
        self.after(600, self._apply_video_scale)

    # ==================== 🎨 THEME SYSTEM ====================
    def _get_palette(self):
        """Get the current color palette based on theme name + mode"""
        return THEMES[self.current_color_theme][self.current_theme]

    def cycle_color_theme(self):
        """Cycle to the next color theme (6 total)"""
        idx = THEME_ORDER.index(self.current_color_theme)
        next_idx = (idx + 1) % len(THEME_ORDER)
        self.current_color_theme = THEME_ORDER[next_idx]
        self.apply_theme(self.current_theme, self.current_color_theme)
        self.save_config()

    def toggle_theme(self):
        """Toggle between dark and light mode"""
        self.current_theme = "light" if self.current_theme == "dark" else "dark"
        self.apply_theme(self.current_theme, self.current_color_theme)
        self.save_config()

    def apply_theme(self, mode, color_theme):
        """Apply theme — updates ALL widgets dynamically"""
        self.current_theme = mode
        self.current_color_theme = color_theme
        self.C = THEMES[color_theme][mode]
        ctk.set_appearance_mode(mode)

        # Update main window + welcome screen
        self.configure(fg_color=self.C["bg_main"])

        if hasattr(self, "welcome_frame"):
            self.welcome_frame.configure(fg_color=self.C["bg_main"])
            self.hero_banner.configure(fg_color=self.C["bg_card"])
            self.hero_title.configure(text_color=self.C["text_primary"])
            self.hero_sub.configure(text_color=self.C["accent_1"])
            self.hero_tagline.configure(text_color=self.C["text_secondary"])
            self.card.configure(fg_color=self.C["bg_card"],
                                border_color=self.C["border"])

            # Rebuild the gradient strip
            for w in self.strip_frame.winfo_children():
                w.destroy()
            for key in ["accent_1", "accent_2", "accent_3", "accent_4", "accent_5", "accent_6"]:
                strip = ctk.CTkFrame(self.strip_frame, height=6, fg_color=self.C[key], corner_radius=0)
                strip.pack(side="left", fill="x", expand=True)

            # Main 3 buttons
            self.btn_load.configure(fg_color=self.C["accent_1"], hover_color=self.C["accent_3"])
            self.btn_api.configure(fg_color=self.C["accent_2"], hover_color=self.C["accent_5"])
            self.btn_local.configure(fg_color=self.C["accent_3"], hover_color=self.C["accent_6"])

            # Bottom action buttons
            self.btn_color_theme.configure(
                text=f"🎨   {THEMES[color_theme]['name']}",
                fg_color=self.C["bg_hover"],
                hover_color=self.C["accent_3"],
                text_color=self.C["text_primary"],
                border_color=self.C["border"]
            )
            self.btn_favorites_home.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_4"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            if mode == "dark":
                self.btn_theme.configure(
                    text="🌙   Dark",
                    fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
                    text_color=self.C["text_primary"], border_color=self.C["border"]
                )
            else:
                self.btn_theme.configure(
                    text="☀️   Light",
                    fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
                    text_color=self.C["text_primary"], border_color=self.C["border"]
                )

        # Update player screen
        if hasattr(self, "player_frame"):
            self.player_frame.configure(fg_color=self.C["bg_main"])
            self.top_bar.configure(fg_color=self.C["bg_card"])
            self.cat_bar.configure(fg_color=self.C["bg_panel"])
            self.left_panel.configure(fg_color=self.C["bg_card"], border_color=self.C["border"])
            self.right_panel.configure(fg_color=self.C["bg_card"], border_color=self.C["border"])

            self.playlist_title.configure(text_color=self.C["text_primary"])
            self.search_entry.configure(
                fg_color=self.C["bg_input"], border_color=self.C["border"],
                text_color=self.C["text_primary"],
                placeholder_text_color=self.C["text_muted"]
            )

            # Top bar buttons
            self.btn_back.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_theme_player.configure(
                text="🌙" if mode == "dark" else "☀️",
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_2"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_color_theme_player.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_3"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_fav_view.configure(
                fg_color=self.C["accent_4"], hover_color=self.C["accent_6"]
            )

            # Category buttons
            if self.current_category == "live":
                self.btn_live.configure(fg_color=self.C["accent_1"], text_color="#ffffff")
                self.btn_movies.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
                self.btn_series.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            elif self.current_category == "movies":
                self.btn_live.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
                self.btn_movies.configure(fg_color=self.C["accent_4"], text_color="#ffffff")
                self.btn_series.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            else:
                self.btn_live.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
                self.btn_movies.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
                self.btn_series.configure(fg_color=self.C["accent_2"], text_color="#ffffff")

            # Headers
            self.pkg_header_lbl.configure(text_color=self.C["accent_1"])
            self.ch_header_lbl.configure(text_color=self.C["accent_2"])

            # Progress + volume sliders
            self.progress_slider.configure(
                progress_color=self.C["accent_1"],
                button_color=self.C["accent_2"],
                button_hover_color=self.C["accent_3"],
                fg_color=self.C["bg_hover"]
            )
            self.volume_slider.configure(
                progress_color=self.C["accent_2"],
                button_color=self.C["accent_1"],
                button_hover_color=self.C["accent_3"],
                fg_color=self.C["bg_hover"]
            )

            # Bottom controls
            self.selected_label.configure(text_color=self.C["text_primary"])
            self.data_label.configure(text_color=self.C["text_muted"])
            self.btn_mute.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_fullscreen.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_toggle_sidebar.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_1"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_external_vlc.configure(
                fg_color=self.C["accent_4"], hover_color=self.C["accent_6"]
            )
            self.btn_zoom_reset.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["accent_3"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_stop.configure(
                fg_color=self.C["bg_hover"], hover_color=self.C["danger"],
                text_color=self.C["text_primary"], border_color=self.C["border"]
            )
            self.btn_play.configure(
                fg_color=self.C["accent_5"], hover_color=self.C["success"]
            )

            # Refresh channel rows and packages
            self.populate_channels(self.channels)
            self.populate_packages(
                self.live_categories if self.current_category == "live" else
                self.movie_categories if self.current_category == "movies" else
                self.series_categories
            )

    # ==================== External VLC ====================
    def play_in_external_vlc(self):
        target_url = None
        target_name = None
        if self.selected_channel:
            target_name, target_url = self.selected_channel
        elif self._last_played:
            target_name, target_url = self._last_played
        if not target_url:
            messagebox.showwarning("Warning", "Please select a channel first")
            return
        vlc_path = self._find_vlc_path()
        if not vlc_path:
            messagebox.showerror("VLC Not Found",
                "VLC Media Player was not found on your system.\n\n"
                "Please install VLC from:\nhttps://www.videolan.org/vlc/")
            return
        try:
            self._stop_internal_only()
            subprocess.Popen([vlc_path, target_url])
            self.selected_label.configure(text=f"Opened in VLC: {target_name}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch VLC:\n{e}")

    def play_url_in_external_vlc(self, name, url):
        vlc_path = self._find_vlc_path()
        if not vlc_path:
            messagebox.showerror("VLC Not Found",
                "VLC Media Player was not found on your system.\n\n"
                "Please install VLC from:\nhttps://www.videolan.org/vlc/")
            return
        try:
            self._stop_internal_only()
            subprocess.Popen([vlc_path, url])
            self.selected_label.configure(text=f"Opened in VLC: {name}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch VLC:\n{e}")

    def _find_vlc_path(self):
        vlc_in_path = shutil.which("vlc")
        if vlc_in_path:
            return vlc_in_path
        candidates = []
        if sys.platform.startswith("win"):
            candidates = [
                r"C:\Program Files\VideoLAN\VLC\vlc.exe",
                r"C:\Program Files (x86)\VideoLAN\VLC\vlc.exe",
                os.path.expanduser(r"~\AppData\Local\Programs\VideoLAN\VLC\vlc.exe"),
            ]
        elif sys.platform == "darwin":
            candidates = [
                "/Applications/VLC.app/Contents/MacOS/VLC",
                os.path.expanduser("~/Applications/VLC.app/Contents/MacOS/VLC"),
            ]
        else:
            candidates = [
                "/usr/bin/vlc", "/usr/local/bin/vlc",
                "/snap/bin/vlc",
                "/var/lib/flatpak/exports/bin/org.videolan.VLC",
            ]
        for path in candidates:
            if os.path.isfile(path):
                return path
        return None

    # ==================== Internal Player Control ====================
    def _stop_internal_only(self):
        self.stop_data_counter()
        self.stop_progress_updater()
        if self.player:
            try:
                self.player.stop()
            except Exception as e:
                print("Internal stop error:", e)
        self.data_label.configure(text="Data: 0.00 MB")
        try:
            self.progress_slider.set(0)
            self.time_current.configure(text="00:00")
            self.time_total.configure(text="00:00")
        except:
            pass

    # ==================== Cinema Mode ====================
    def _on_mouse_motion(self, event=None):
        if not self.cinema_mode:
            return
        self._show_all_bars()
        if self.hide_ui_timer:
            self.after_cancel(self.hide_ui_timer)
        self.hide_ui_timer = self.after(3000, self._hide_all_bars)

    def _show_all_bars(self):
        if self.ui_visible:
            return
        self.ui_visible = True
        try:
            if not self.top_bar.winfo_ismapped():
                self.top_bar.pack(fill="x", before=self.content_frame)
            if not self.cat_bar.winfo_ismapped():
                self.cat_bar.pack(fill="x", before=self.content_frame)
            if not self.progress_frame.winfo_ismapped():
                self.progress_frame.pack(side="bottom", fill="x", padx=14, pady=(0, 4))
            if not self.controls.winfo_ismapped():
                self.controls.pack(side="bottom", fill="x", padx=12, pady=(0, 10))
            if (not self.left_panel.winfo_ismapped() and
                    not hasattr(self, "_manually_hidden_sidebar")):
                self.left_panel.pack(side="left", fill="y", padx=(0, 10),
                                     before=self.right_panel)
                self.left_panel_visible = True
        except Exception as e:
            print("show bars error:", e)

    def _hide_all_bars(self):
        if not self.cinema_mode or not self.ui_visible:
            return
        self.ui_visible = False
        try:
            self.top_bar.pack_forget()
            self.cat_bar.pack_forget()
            self.progress_frame.pack_forget()
            self.controls.pack_forget()
            if self.left_panel.winfo_ismapped():
                self.left_panel.pack_forget()
                self.left_panel_visible = False
        except Exception as e:
            print("hide bars error:", e)
        self.update_idletasks()
        self.after(50, self._apply_video_scale)

    def enable_cinema_mode(self):
        self.cinema_mode = True
        if self.hide_ui_timer:
            self.after_cancel(self.hide_ui_timer)
        self.hide_ui_timer = self.after(1500, self._hide_all_bars)

    def disable_cinema_mode(self):
        self.cinema_mode = False
        if self.hide_ui_timer:
            self.after_cancel(self.hide_ui_timer)
            self.hide_ui_timer = None
        self._show_all_bars()
        self.update_idletasks()
        self.after(50, self._apply_video_scale)

    def toggle_cinema_mode(self):
        if self.cinema_mode:
            self.disable_cinema_mode()
        else:
            self.enable_cinema_mode()

    # ==================== Video Zoom ====================
    def _apply_video_scale(self):
        try:
            if self.video_scale > 1.2 and not self.cinema_mode:
                self.enable_cinema_mode()
            elif self.video_scale <= 1.2 and self.cinema_mode:
                self.disable_cinema_mode()

            if not self.cinema_mode:
                if self.video_scale > 1.2:
                    if self.left_panel.winfo_ismapped():
                        self.left_panel.pack_forget()
                        self.left_panel_visible = False
                else:
                    if (not self.left_panel.winfo_ismapped() and
                            not hasattr(self, "_manually_hidden_sidebar")):
                        self.left_panel.pack(side="left", fill="y", padx=(0, 10),
                                             before=self.right_panel)
                        self.left_panel_visible = True

            self.update_idletasks()
            self.video_holder.update_idletasks()
            holder_w = self.video_holder.winfo_width()
            holder_h = self.video_holder.winfo_height()
            if holder_w < 50 or holder_h < 50:
                self.after(150, self._apply_video_scale)
                return

            if abs(self.video_scale - 1.0) < 0.01:
                self.video_frame.place_configure(
                    relx=0, rely=0, anchor="nw",
                    relwidth=1, relheight=1, width=0, height=0)
            else:
                max_w = holder_w - 16
                max_h = holder_h - 16
                new_w = max(150, int(max_w * self.video_scale))
                new_h = max(100, int(max_h * self.video_scale))
                self.video_frame.place_configure(
                    relx=0.5, rely=0.5, anchor="center",
                    width=new_w, height=new_h,
                    relwidth=0, relheight=0)

            self.video_holder.update_idletasks()
            self.video_frame.update_idletasks()
            self.update_idletasks()

            if self.player:
                try:
                    self.player.set_hwnd(self.video_frame.winfo_id())
                    self.after(70, self._refresh_vlc_window)
                except Exception as e:
                    print("set_hwnd error:", e)
        except Exception as e:
            print("Video scale error:", e)

    def _refresh_vlc_window(self):
        if not self.player:
            return
        try:
            self.video_frame.update_idletasks()
            self.player.set_hwnd(self.video_frame.winfo_id())
        except:
            pass

    def _on_holder_resize(self, event=None):
        if abs(self.video_scale - 1.0) > 0.01:
            self.after(80, self._apply_video_scale)

    def enlarge_video(self):
        if hasattr(self, "_manually_hidden_sidebar"):
            del self._manually_hidden_sidebar
        self.video_scale = min(2.5, round(self.video_scale + 0.1, 2))
        self._apply_video_scale()
        self.save_config()

    def shrink_video(self):
        self.video_scale = max(0.4, round(self.video_scale - 0.1, 2))
        self._apply_video_scale()
        self.save_config()

    def reset_video_size(self):
        self.video_scale = 1.0
        self.disable_cinema_mode()
        if hasattr(self, "_manually_hidden_sidebar"):
            del self._manually_hidden_sidebar
        if not self.left_panel.winfo_ismapped():
            self.left_panel.pack(side="left", fill="y", padx=(0, 10),
                                 before=self.right_panel)
            self.left_panel_visible = True
        self.video_frame.place_configure(
            relx=0, rely=0, anchor="nw",
            relwidth=1, relheight=1, width=0, height=0)
        self.update_idletasks()
        self.video_holder.update_idletasks()
        self.video_frame.update_idletasks()
        if self.player:
            try:
                self.player.set_hwnd(self.video_frame.winfo_id())
                self.after(70, self._refresh_vlc_window)
            except:
                pass
        self.save_config()

    def toggle_left_panel(self):
        if self.left_panel.winfo_ismapped():
            self.left_panel.pack_forget()
            self.left_panel_visible = False
            self._manually_hidden_sidebar = True
        else:
            self.left_panel.pack(side="left", fill="y", padx=(0, 10),
                                 before=self.right_panel)
            self.left_panel_visible = True
            if hasattr(self, "_manually_hidden_sidebar"):
                del self._manually_hidden_sidebar
        self.update_idletasks()
        self.after(50, self._apply_video_scale)

    # ==================== Fullscreen ====================
    def toggle_fullscreen(self):
        if self.is_fullscreen:
            self.exit_fullscreen()
        else:
            self.enter_fullscreen()

    def enter_fullscreen(self):
        self.is_fullscreen = True
        self.attributes("-fullscreen", True)
        self.btn_fullscreen.configure(text="⛶  Exit")
        self.enable_cinema_mode()

    def exit_fullscreen(self, event=None):
        self.is_fullscreen = False
        self.attributes("-fullscreen", False)
        self.btn_fullscreen.configure(text="⛶  Fullscreen")

    # ==================== Progress / Seek ====================
    def format_time(self, ms):
        if ms <= 0:
            return "00:00"
        seconds = int(ms / 1000)
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        if h > 0:
            return f"{h:02d}:{m:02d}:{s:02d}"
        return f"{m:02d}:{s:02d}"

    def update_progress(self):
        if self.player is None or self.is_seeking:
            self.progress_timer = self.after(500, self.update_progress)
            return
        try:
            length = self.player.get_length()
            current = self.player.get_time()
            if length > 0:
                pos = (current / length) * 1000
                self.progress_slider.set(pos)
                self.time_current.configure(text=self.format_time(current))
                self.time_total.configure(text=self.format_time(length))
            else:
                self.progress_slider.set(0)
                self.time_current.configure(text="LIVE")
                self.time_total.configure(text="--:--")
        except:
            pass
        self.progress_timer = self.after(500, self.update_progress)

    def on_seek_start(self, event):
        self.is_seeking = True

    def on_seek_end(self, event):
        self.is_seeking = False
        self.seek_to_position()

    def on_progress_change(self, value):
        pass

    def seek_to_position(self):
        if not self.player:
            return
        try:
            length = self.player.get_length()
            if length > 0:
                pos = self.progress_slider.get() / 1000.0
                self.player.set_time(int(length * pos))
        except:
            pass

    def start_progress_updater(self):
        self.stop_progress_updater()
        self.update_progress()

    def stop_progress_updater(self):
        if self.progress_timer:
            self.after_cancel(self.progress_timer)
            self.progress_timer = None
        self.progress_slider.set(0)
        self.time_current.configure(text="00:00")
        self.time_total.configure(text="00:00")

    # ==================== Volume & Data ====================
    def on_volume_change(self, value):
        self.volume = int(float(value))
        self.vol_label.configure(text=f"{self.volume}%")
        if self.player and not self.is_muted:
            self.player.audio_set_volume(self.volume)
        if self.volume == 0:
            self.btn_mute.configure(text="🔇")
        else:
            self.btn_mute.configure(text="🔊")
            self.is_muted = False

    def toggle_mute(self):
        if not self.player:
            return
        self.is_muted = not self.is_muted
        if self.is_muted:
            self.player.audio_set_volume(0)
            self.btn_mute.configure(text="🔇")
        else:
            self.player.audio_set_volume(self.volume)
            self.btn_mute.configure(text="🔊")

    def start_data_counter(self):
        self.data_used_mb = 0.0
        self.playing_start_time = time.time()
        self.update_data_usage()

    def update_data_usage(self):
        if self.playing_start_time is None:
            return
        elapsed = time.time() - self.playing_start_time
        self.data_used_mb = elapsed * 0.4375
        self.data_label.configure(text=f"Data: {self.data_used_mb:.2f} MB")
        self.data_timer = self.after(1000, self.update_data_usage)

    def stop_data_counter(self):
        if self.data_timer:
            self.after_cancel(self.data_timer)
            self.data_timer = None
        self.playing_start_time = None

    # ==================== Config ====================
    def load_config(self):
        self.config = {
            "last_playlist": None, "favorites": [], "xtream": {},
            "theme": "dark", "color_theme": "ocean", "video_scale": 1.0
        }
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    self.config = json.load(f)
                self.favorites = self.config.get("favorites", [])
                self.current_theme = self.config.get("theme", "dark")
                self.current_color_theme = self.config.get("color_theme", "ocean")
                if self.current_color_theme not in THEMES:
                    self.current_color_theme = "ocean"
                self.video_scale = self.config.get("video_scale", 1.0)
            except:
                pass

    def save_config(self):
        self.config["favorites"] = self.favorites
        self.config["theme"] = self.current_theme
        self.config["color_theme"] = self.current_color_theme
        self.config["video_scale"] = self.video_scale
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print("Error saving config:", e)

    # ==================== Categories ====================
    def switch_main_category(self, category):
        self.current_category = category
        self.current_package = None
        if category == "live":
            self.btn_live.configure(fg_color=self.C["accent_1"], text_color="#ffffff")
            self.btn_movies.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            self.btn_series.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
        elif category == "movies":
            self.btn_live.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            self.btn_movies.configure(fg_color=self.C["accent_4"], text_color="#ffffff")
            self.btn_series.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
        else:
            self.btn_live.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            self.btn_movies.configure(fg_color=self.C["bg_hover"], text_color=self.C["text_primary"])
            self.btn_series.configure(fg_color=self.C["accent_2"], text_color="#ffffff")

        if category == "live":
            cats = self.live_categories
            self.playlist_title.configure(text="📺  Live TV  ·  Select Category")
        elif category == "movies":
            cats = self.movie_categories
            self.playlist_title.configure(text="🎬  Movies  ·  Select Category")
        else:
            cats = self.series_categories
            self.playlist_title.configure(text="🍿  Series  ·  Select Category")

        self.search_var.set("")
        self.populate_packages(cats)
        self.channels = []
        self.populate_channels([])

    def populate_packages(self, categories):
        for w in self.packages_frame.winfo_children():
            w.destroy()
        if not categories:
            ctk.CTkLabel(self.packages_frame, text="No categories found",
                         font=ctk.CTkFont(size=13),
                         text_color=self.C["text_muted"]).pack(pady=10)
            return
        for cat in categories:
            cat_id = cat.get("category_id")
            cat_name = cat.get("category_name", "Unknown")
            is_active = (self.current_package == cat_id)
            btn = ctk.CTkButton(
                self.packages_frame, text=f"   {cat_name}", height=40, corner_radius=10,
                font=ctk.CTkFont(size=14, weight="bold" if is_active else "normal"),
                fg_color=self.C["accent_1"] if is_active else self.C["bg_hover"],
                hover_color=self.C["accent_3"] if is_active else self.C["accent_1"],
                text_color="#ffffff" if is_active else self.C["text_primary"],
                anchor="w",
                border_width=0 if is_active else 1,
                border_color=self.C["border"],
                command=lambda cid=cat_id, cname=cat_name: self.select_package(cid, cname)
            )
            btn.pack(fill="x", pady=3, padx=3)

    def select_package(self, category_id, category_name=None):
        self.current_package = category_id
        if self.current_category == "live":
            source = self.live_channels
            title = "📺  Live TV"
        elif self.current_category == "movies":
            source = self.movie_channels
            title = "🎬  Movies"
        else:
            source = self.series_channels
            title = "🍿  Series"

        if category_id is None:
            self.channels = source
            self.playlist_title.configure(text=f"{title}  ·  All ({len(self.channels)})")
        else:
            self.channels = [c for c in source if c[2] == str(category_id)]
            self.playlist_title.configure(text=f"{title}  ·  {category_name} ({len(self.channels)})")

        self.populate_packages(
            self.live_categories if self.current_category == "live" else
            self.movie_categories if self.current_category == "movies" else
            self.series_categories
        )
        self.populate_channels(self.channels)

    # ==================== Load Playlist ====================
    def load_playlist_menu(self):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Load Playlist")
        dialog.geometry("460x260")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=self.C["bg_card"])

        ctk.CTkLabel(dialog, text="Choose Loading Method",
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=self.C["text_primary"]).pack(pady=20)

        ctk.CTkButton(dialog, text="📁   From File  (M3U / M3U8)",
                      width=340, height=48, corner_radius=12,
                      font=ctk.CTkFont(size=13, weight="bold"),
                      fg_color=self.C["accent_1"], hover_color=self.C["accent_3"],
                      text_color="#ffffff",
                      command=lambda: [dialog.destroy(), self.load_from_file_dialog()]).pack(pady=8)

        ctk.CTkButton(dialog, text="🔗   From URL",
                      width=340, height=48, corner_radius=12,
                      font=ctk.CTkFont(size=13, weight="bold"),
                      fg_color=self.C["accent_2"], hover_color=self.C["accent_5"],
                      text_color="#ffffff",
                      command=lambda: [dialog.destroy(), self.load_from_url_dialog()]).pack(pady=8)

    def load_from_file_dialog(self):
        path = filedialog.askopenfilename(title="Select Playlist",
                                          filetypes=[("Playlist", "*.m3u *.m3u8"), ("All", "*.*")])
        if path:
            self.load_from_file(path)

    def load_from_file(self, path):
        try:
            content = Path(path).read_text(encoding="utf-8", errors="ignore")
            self._process_m3u_content(content, Path(path).name)
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def load_from_url_dialog(self):
        url = simpledialog.askstring("Playlist URL", "Enter M3U / M3U8 URL:")
        if url:
            self.load_from_url(url.strip())

    def load_from_url(self, url):
        self.playlist_title.configure(text="⏳  Loading...")
        self.show_player()
        self.populate_channels([])
        threading.Thread(target=self._download_m3u, args=(url,), daemon=True).start()

    def _download_m3u(self, url):
        try:
            r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
            r.raise_for_status()
            self.after(0, lambda: self._process_m3u_content(r.text, "URL Playlist"))
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("Error", str(e)))

    def _process_m3u_content(self, content, title):
        groups = {}
        for name, url, group in self.parse_m3u_content(content):
            g = group if group else "Uncategorized"
            if g not in groups:
                groups[g] = []
            groups[g].append((name, url, g))

        self.live_channels = []
        self.live_categories = []
        for i, (gname, items) in enumerate(groups.items()):
            self.live_categories.append({"category_id": str(i), "category_name": gname})
            for name, url, _ in items:
                self.live_channels.append((name, url, str(i)))

        self.movie_channels = []
        self.series_channels = []
        self.movie_categories = []
        self.series_categories = []
        self.is_xtream = False
        self.show_player()
        self.switch_main_category("live")

    def parse_m3u_content(self, content):
        channels = []
        name, group = "Unknown", ""
        for line in content.splitlines():
            line = line.strip()
            if line.startswith("#EXTINF:"):
                gm = re.search(r'group-title="([^"]+)"', line)
                group = gm.group(1) if gm else ""
                comma = line.rfind(",")
                name = line[comma+1:].strip() if comma != -1 else "Unknown"
            elif line and not line.startswith("#"):
                channels.append((name, line, group))
        return channels

    # ==================== Xtream ====================
    def open_xtream_login(self):
        dialog = ctk.CTkToplevel(self)
        dialog.title("Xtream Codes Login")
        dialog.geometry("480x420")
        dialog.resizable(False, False)
        dialog.transient(self)
        dialog.grab_set()
        dialog.configure(fg_color=self.C["bg_card"])

        ctk.CTkLabel(dialog, text="Xtream Codes Login",
                     font=ctk.CTkFont(size=18, weight="bold"),
                     text_color=self.C["text_primary"]).pack(pady=15)
        xt = self.config.get("xtream", {})

        for lbl_text, key, show in [("Server URL", "server", False),
                                     ("Username", "username", False),
                                     ("Password", "password", True)]:
            ctk.CTkLabel(dialog, text=lbl_text,
                         font=ctk.CTkFont(size=12, weight="bold"),
                         text_color=self.C["text_secondary"]).pack(anchor="w", padx=40, pady=(6, 0))
            entry = ctk.CTkEntry(dialog, width=380, height=38, corner_radius=10,
                                 show="*" if show else "",
                                 fg_color=self.C["bg_input"],
                                 border_color=self.C["border"],
                                 text_color=self.C["text_primary"])
            entry.pack(pady=4)
            entry.insert(0, xt.get(key, ""))
            if key == "server":
                server_entry = entry
            elif key == "username":
                user_entry = entry
            else:
                pass_entry = entry

        def do_login():
            server = server_entry.get().strip().rstrip("/")
            username = user_entry.get().strip()
            password = pass_entry.get().strip()
            if not all([server, username, password]):
                messagebox.showwarning("Warning", "Fill all fields")
                return
            dialog.destroy()
            self.login_xtream(server, username, password)

        ctk.CTkButton(dialog, text="Login", width=220, height=46, corner_radius=12,
                      font=ctk.CTkFont(size=14, weight="bold"),
                      fg_color=self.C["accent_1"], hover_color=self.C["accent_3"],
                      text_color="#ffffff",
                      command=do_login).pack(pady=22)

    def login_xtream(self, server, username, password):
        self.live_channels = self.movie_channels = self.series_channels = []
        self.live_categories = self.movie_categories = self.series_categories = []
        self.playlist_title.configure(text="⏳  Connecting...")
        self.show_player()
        self.populate_packages([])
        self.populate_channels([])
        self.selected_label.configure(text="Loading Live TV...")
        threading.Thread(target=self._xtream_worker,
                         args=(server, username, password), daemon=True).start()

    def _xtream_worker(self, server, username, password):
        headers = {"User-Agent": "Mozilla/5.0"}
        base = f"{server}/player_api.php?username={username}&password={password}"
        try:
            r = requests.get(base, headers=headers, timeout=12)
            r.raise_for_status()
            if r.json().get("user_info", {}).get("auth") != 1:
                raise Exception("Authentication failed")

            cats = requests.get(f"{base}&action=get_live_categories", headers=headers, timeout=15).json()
            streams = requests.get(f"{base}&action=get_live_streams", headers=headers, timeout=25).json()
            live_cats = [{"category_id": c["category_id"], "category_name": c["category_name"]} for c in cats]
            live_list = [(s.get("name", "Unknown"),
                          f"{server}/live/{username}/{password}/{s.get('stream_id')}.ts",
                          str(s.get("category_id", ""))) for s in streams]
            self.after(0, lambda: self._finish_live(server, username, password, live_cats, live_list))

            try:
                mcats = requests.get(f"{base}&action=get_vod_categories", headers=headers, timeout=15).json()
                mstreams = requests.get(f"{base}&action=get_vod_streams", headers=headers, timeout=30).json()
                movie_cats = [{"category_id": c["category_id"], "category_name": c["category_name"]} for c in mcats]
                movie_list = [(s.get("name", "Unknown"),
                               f"{server}/movie/{username}/{password}/{s.get('stream_id')}.{s.get('container_extension', 'mp4')}",
                               str(s.get("category_id", ""))) for s in mstreams]
                self.after(0, lambda: self._finish_movies(movie_cats, movie_list))
            except:
                pass

            try:
                scats = requests.get(f"{base}&action=get_series_categories", headers=headers, timeout=15).json()
                sstreams = requests.get(f"{base}&action=get_series", headers=headers, timeout=30).json()
                series_cats = [{"category_id": c["category_id"], "category_name": c["category_name"]} for c in scats]
                series_list = [(s.get("name", "Unknown"),
                                f"{server}/series/{username}/{password}/{s.get('series_id')}",
                                str(s.get("category_id", ""))) for s in sstreams]
                self.after(0, lambda: self._finish_series(series_cats, series_list))
            except:
                pass

        except Exception as e:
            self.after(0, lambda: self._on_xtream_error(str(e)))

    def _finish_live(self, server, username, password, cats, channels):
        self.live_categories = cats
        self.live_channels = channels
        self.is_xtream = True
        self.xtream_info = {"server": server, "username": username, "password": password}
        self.config["xtream"] = self.xtream_info
        self.save_config()
        self.switch_main_category("live")
        self.selected_label.configure(text="Live TV ready")

    def _finish_movies(self, cats, channels):
        self.movie_categories = cats
        self.movie_channels = channels
        if self.current_category == "movies":
            self.switch_main_category("movies")

    def _finish_series(self, cats, channels):
        self.series_categories = cats
        self.series_channels = channels
        if self.current_category == "series":
            self.switch_main_category("series")
        self.selected_label.configure(text="All categories loaded")

    def _on_xtream_error(self, msg):
        messagebox.showerror("Xtream Error", msg)
        self.show_welcome()

    # ==================== Favorites & UI ====================
    def is_favorite(self, name, url):
        return any(f["name"] == name and f["url"] == url for f in self.favorites)

    def toggle_favorite(self, name, url):
        if self.is_favorite(name, url):
            self.favorites = [f for f in self.favorites if not (f["name"] == name and f["url"] == url)]
        else:
            self.favorites.append({"name": name, "url": url})
        self.save_config()
        self.populate_channels(self.channels)

    def show_favorites(self):
        if not self.favorites:
            messagebox.showinfo("Favorites", "No favorites yet")
            return
        self.channels = [(f["name"], f["url"], "") for f in self.favorites]
        self.playlist_title.configure(text=f"★  Favorites ({len(self.channels)})")
        self.populate_packages([])
        self.populate_channels(self.channels)
        self.show_player()


    def show_about(self):
        about_win = ctk.CTkToplevel(self)
        about_win.title(f"About - {APP_NAME}")
        about_win.geometry("560x750")
        about_win.transient(self)
        about_win.grab_set()
        about_win.configure(fg_color=self.C["bg_main"])
        about_win.resizable(False, False)
        about_win.geometry(f"+{self.winfo_screenwidth()//2 - 280}+{self.winfo_screenheight()//2 - 375}")
        main = ctk.CTkFrame(about_win, fg_color=self.C["bg_card"], corner_radius=20, border_width=1, border_color=self.C["border"])
        main.pack(fill="both", expand=True, padx=15, pady=15)
        ctk.CTkLabel(main, text="📺", font=ctk.CTkFont(size=64)).pack(pady=(20,5))
        ctk.CTkLabel(main, text=APP_NAME, font=ctk.CTkFont(size=22, weight="bold"), text_color=self.C["text_primary"]).pack()
        ctk.CTkLabel(main, text=f"Version {APP_VERSION} | VLC 64-bit Required", font=ctk.CTkFont(size=11), text_color=self.C["text_muted"]).pack(pady=2)
        ctk.CTkFrame(main, height=1, fg_color=self.C["border"]).pack(fill="x", padx=30, pady=12)
        ctk.CTkLabel(main, text="Developed By", font=ctk.CTkFont(size=11), text_color=self.C["text_muted"]).pack()
        ctk.CTkLabel(main, text="AMRTECH", font=ctk.CTkFont(size=32, weight="bold"), text_color=self.C["accent_1"]).pack(pady=2)
        ctk.CTkLabel(main, text="Professional IPTV Solutions", font=ctk.CTkFont(size=11), text_color=self.C["text_secondary"]).pack()
        ctk.CTkFrame(main, height=1, fg_color=self.C["border"]).pack(fill="x", padx=30, pady=12)
        warn_frame = ctk.CTkFrame(main, fg_color="#2a1a1a", corner_radius=8, border_width=1, border_color="#ff1a1a")
        warn_frame.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(warn_frame, text="⚠️ يتطلب VLC 64-bit من videolan.org", font=ctk.CTkFont(size=11, weight="bold"), text_color="#ff7b72").pack(pady=6)
        ctk.CTkLabel(main, text="🌐 روابطي الرسمية", font=ctk.CTkFont(size=13, weight="bold"), text_color=self.C["text_primary"]).pack(pady=(12,5))
        links_frame = ctk.CTkFrame(main, fg_color="transparent")
        links_frame.pack(fill="x", padx=10)
        def make_link_btn(parent, icon, title, url, color):
            def open_url():
                webbrowser.open(url)
            btn = ctk.CTkButton(parent, text=f"{icon} {title}", width=480, height=38, corner_radius=10,
                                fg_color=color, hover_color=self.C["bg_hover"],
                                border_width=1, border_color=self.C["border"],
                                text_color="white",
                                font=ctk.CTkFont(size=11, weight="bold"), anchor="w", command=open_url)
            btn.pack(pady=3)
            return btn
        make_link_btn(links_frame, "🌐", "Website - Profilable", APP_WEBSITE_MAIN, "#58a6ff")
        make_link_btn(links_frame, "🛒", "Shop - Shoppy.gg", APP_WEBSITE_SHOP, "#7ee787")
        make_link_btn(links_frame, "🔗", "Spoo.me - Amrtech", APP_WEBSITE_SPOO, "#a371f7")
        make_link_btn(links_frame, "📢", "Join Backup - Telegram", APP_TELEGRAM_BACKUP, "#56d4dd")
        make_link_btn(links_frame, "⬇️", "تحميل VLC 64-bit (مطلوب)", APP_VLC_URL, "#ff7b72")
        ctk.CTkFrame(main, height=1, fg_color=self.C["border"]).pack(fill="x", padx=30, pady=12)
        ctk.CTkLabel(main, text="© 2025 AMRTECH - All Rights Reserved\nIPTV Smarters Pro - Custom Edition", font=ctk.CTkFont(size=9), text_color=self.C["text_muted"], justify="center").pack(pady=5)
        ctk.CTkButton(main, text="إغلاق", width=200, height=32, corner_radius=8, fg_color=self.C["bg_hover"], border_width=1, border_color=self.C["border"], text_color=self.C["text_primary"], command=about_win.destroy).pack(pady=10)


    def show_welcome(self):
        self.stop_playback()
        self.exit_fullscreen()
        self.disable_cinema_mode()
        self.player_frame.pack_forget()
        self.welcome_frame.pack(fill="both", expand=True)
        # AMRTECH branding
        try:
            bl = ctk.CTkLabel(self.welcome_frame, text="© 2025 AMRTECH - VLC 64-bit Required | profilable.com/AMRTECH-VIP", font=ctk.CTkFont(size=10), text_color=self.C["text_muted"])
            bl.pack(side="bottom", pady=2)
            ab = ctk.CTkButton(self.welcome_frame, text="👤 About AMRTECH", width=160, height=30, corner_radius=8, fg_color=self.C["accent_3"], hover_color=self.C["accent_1"], font=ctk.CTkFont(size=11, weight="bold"), command=self.show_about)
            ab.pack(side="bottom", pady=5)
        except: pass

    def show_player(self):
        self.welcome_frame.pack_forget()
        self.player_frame.pack(fill="both", expand=True)

    def populate_channels(self, channel_list):
        for w in self.channels_container.winfo_children():
            w.destroy()
        if not channel_list:
            ctk.CTkLabel(self.channels_container,
                         text="Select a category to view channels",
                         font=ctk.CTkFont(size=13),
                         text_color=self.C["text_muted"]).pack(pady=24)
            return
        for idx, item in enumerate(channel_list):
            name, url = item[0], item[1]
            frame = ctk.CTkFrame(
                self.channels_container, height=54, corner_radius=10,
                fg_color=self.C["bg_row"],
                border_width=1, border_color=self.C["border"]
            )
            frame.pack(fill="x", pady=3, padx=3)
            frame.pack_propagate(False)

            ctk.CTkLabel(
                frame, text=f"{idx+1:03d}",
                width=46, height=32,
                font=ctk.CTkFont(size=12, weight="bold"),
                text_color=self.C["accent_2"],
                fg_color=self.C["bg_hover"],
                corner_radius=8
            ).pack(side="left", padx=6)

            name_lbl = ctk.CTkLabel(
                frame, text=name,
                font=ctk.CTkFont(size=15, weight="bold"),
                text_color=self.C["text_primary"],
                anchor="w", cursor="hand2"
            )
            name_lbl.pack(side="left", fill="x", expand=True, padx=(6, 8))

            is_fav = self.is_favorite(name, url)
            ctk.CTkButton(
                frame, text="★" if is_fav else "☆", width=38, height=38, corner_radius=10,
                font=ctk.CTkFont(size=15),
                fg_color=self.C["accent_4"] if is_fav else self.C["bg_hover"],
                hover_color=self.C["accent_6"],
                text_color="#ffffff" if is_fav else self.C["text_primary"],
                border_width=0 if is_fav else 1,
                border_color=self.C["border"],
                command=lambda n=name, u=url: self.toggle_favorite(n, u)
            ).pack(side="right", padx=3)

            ctk.CTkButton(
                frame, text="▶", width=40, height=38, corner_radius=10,
                font=ctk.CTkFont(size=15, weight="bold"),
                fg_color=self.C["accent_5"], hover_color=self.C["success"],
                text_color="#000000",
                command=lambda n=name, u=url: self.play_channel(n, u)
            ).pack(side="right", padx=3)

            ctk.CTkButton(
                frame, text="🎬", width=40, height=38, corner_radius=10,
                font=ctk.CTkFont(size=14),
                fg_color=self.C["accent_4"], hover_color=self.C["accent_6"],
                text_color="#ffffff",
                command=lambda n=name, u=url: self.play_url_in_external_vlc(n, u)
            ).pack(side="right", padx=3)

            def make_play(n=name, u=url):
                return lambda e=None: self.play_channel(n, u)

            name_lbl.bind("<Button-1>", make_play())
            frame.bind("<Button-1>", make_play())

    def select_channel(self, name, url):
        self.selected_channel = (name, url)
        self.selected_label.configure(text=f"Selected: {name}")
        self.btn_play.configure(state="normal")

    def filter_channels(self, *args):
        query = self.search_var.get().lower().strip()
        if not query:
            self.populate_channels(self.channels)
        else:
            filtered = [c for c in self.channels if query in c[0].lower()]
            self.populate_channels(filtered)

    def play_selected(self):
        if self.selected_channel:
            self.play_channel(*self.selected_channel)

    def play_channel(self, name, url):
        if not VLC_AVAILABLE or not self.player:
            messagebox.showerror("Error", "python-vlc not installed.\nRun: pip install python-vlc")
            return
        try:
            self.stop_playback()
            media = self.instance.media_new(url)
            self.player.set_media(media)
            self.player.set_hwnd(self.video_frame.winfo_id())
            self.player.audio_set_volume(0 if self.is_muted else self.volume)
            self.player.play()
            self.selected_label.configure(text=f"▶  Now Playing: {name}")
            self.selected_channel = (name, url)
            self._last_played = (name, url)
            self.btn_play.configure(state="normal")
            self.start_data_counter()
            self.start_progress_updater()
        except Exception as e:
            messagebox.showerror("Playback Error", str(e))

    def stop_playback(self):
        self.stop_data_counter()
        self.stop_progress_updater()
        self.exit_fullscreen()
        if self.player:
            try:
                self.player.stop()
            except:
                pass
        self.selected_label.configure(text="Stopped")
        self.data_label.configure(text="Data: 0.00 MB")

    def local_media(self):
        path = filedialog.askopenfilename(
            title="Select Media File",
            filetypes=[("Media", "*.mp4 *.mkv *.avi *.mp3 *.flac"), ("All", "*.*")]
        )
        if path:
            self.play_channel(Path(path).name, path)

    def on_closing(self):
        self.stop_playback()
        self.destroy()


if __name__ == "__main__":
    app = IPTVSmartersPro()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()
