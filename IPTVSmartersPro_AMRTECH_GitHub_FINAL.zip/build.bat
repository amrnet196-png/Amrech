@echo off
echo Building IPTV Smarters Pro - AMRTECH...
pip install -r requirements.txt
pyinstaller --noconfirm --onefile --windowed --name "IPTVSmartersPro_AMRTECH" --icon=AMRTECH_icon.ico --splash=AMRTECH_splash.png --hidden-import=customtkinter --hidden-import=vlc --collect-all customtkinter IPTVSmartersPro_AMRTECH.py
echo Done! Check dist/
pause
