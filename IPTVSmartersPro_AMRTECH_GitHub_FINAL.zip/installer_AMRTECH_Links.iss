; IPTV Smarters Pro - AMRTECH - With Official Links
#define MyAppName "IPTV Smarters Pro - AMRTECH"
#define MyAppVersion "2.0"
#define MyAppPublisher "AMRTECH"
#define MyAppURL "https://profilable.com/AMRTECH-VIP"
#define MyAppExeName "IPTVSmartersPro_AMRTECH.exe"

[Setup]
AppId={{IPTVSmartersPro-AMRTECH-LINKS-2025}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL={#MyAppURL}
AppCopyright=Copyright (C) 2025 AMRTECH - https://profilable.com/AMRTECH-VIP
VersionInfoCompany=AMRTECH
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
OutputBaseFilename=IPTVSmartersPro_AMRTECH_Setup_v2.0_Links
Compression=lzma
WizardStyle=modern
SetupIconFile=icon.ico
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
InfoBeforeFile=VLC_REQUIRED_README.txt

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion
Source: "icon.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\icon.ico"
Name: "{group}\🌐 Website - Profilable"; Filename: "https://profilable.com/AMRTECH-VIP"
Name: "{group}\🛒 Shoppy Store"; Filename: "https://shoppy.gg/product/Z3PuojD"
Name: "{group}\🔗 Spoo.me"; Filename: "https://spoo.me/Amrtech"
Name: "{group}\📢 Telegram Backup"; Filename: "https://t.me/+oGZKLybZyqkxM2Vk"
Name: "{group}\⬇️ تحميل VLC 64-bit"; Filename: "https://www.videolan.org/vlc/"
Name: "{group}\{cm:UninstallProgram,{#MyAppName}}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; IconFilename: "{app}\icon.ico"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "تشغيل البرنامج"; Flags: nowait postinstall skipifsilent
Filename: "https://www.videolan.org/vlc/"; Description: "⬇️ تحميل VLC 64-bit (مطلوب)"; Flags: postinstall shellexec skipifsilent unchecked
